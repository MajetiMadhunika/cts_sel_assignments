package BASECLASS;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Utilities 
{
	static int counter=1;
	WebDriver driver;
	
	public static WebDriver launch_browser(String browser, String url){
		{
			WebDriver driver = null;
			String ch_driver_path="chromedriver.exe";
			String ff_driver_path="D:/my office/my jars/geckodriver-v0.26.0-win64/geckodriver.exe";
			switch(browser)
			{
			case "chrome":
				System.setProperty("webdriver.chrome.driver", ch_driver_path);
				driver = new ChromeDriver();
				break;
				
			case "firefox":
				System.setProperty("webdriver.gecko.driver", ff_driver_path);
				break;
				
			default:
				System.out.println("Supported Browser Options : chrome & firefox");
				break;
			}
			
			driver.get(url);
			driver.manage().window().maximize();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		return driver;
		}
	}
}

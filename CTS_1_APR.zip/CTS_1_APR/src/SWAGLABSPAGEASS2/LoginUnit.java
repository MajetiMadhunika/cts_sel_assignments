package SWAGLABSPAGEASS2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginUnit 
{
	WebDriver driver1;
	@FindBy(id="user-name")
	WebElement uid;
	@FindBy(id="password")
	WebElement pwd;
	@FindBy(className="login_credentials")
	WebElement prd;
	@FindBy(className="btn_action")
	WebElement log_btn;
	
	public LoginUnit(WebDriver driver)
	{
		this.driver1=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void enter_UserName_id(String UserNameid)
	{
		uid.sendKeys(UserNameid);
	}
	   
	public void enter_password_id(String password)
	{
		pwd.sendKeys(password);
	}
	
	public void click_login_btn()
	{
		log_btn.click();
	}
	
	public void do_loginunit(String UserNameid,String password)
	{
		this.enter_UserName_id(UserNameid);
		this.enter_password_id(password);
		this.click_login_btn();
	}
	
	public void successful_login() {
		System.out.println("Login Successful");
	}
	
	public String verify_text() {
		String st1 =  prd.getText();
		return st1;
	}
}

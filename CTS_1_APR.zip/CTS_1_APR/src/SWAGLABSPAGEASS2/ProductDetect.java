package SWAGLABSPAGEASS2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProductDetect {
	WebDriver driver2;
	By login_link = By.linkText("Log in");
	By txt = new By.ByClassName("product_label");
	public ProductDetect(WebDriver driver)
	{
		this.driver2=driver;
	}
	
	public String verify_title()
	{
		String str = driver2.getTitle();
		return str;
	}
	
	public String get_text()
	{
		String act_pro=driver2.findElement(txt).getText();
		return act_pro;
	}
	
}

package SWAGLABSPAGEASS2;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;
import BASECLASS.Utilities;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

public class LoginTest extends excel_io_arr {
	WebDriver driver;
	LoginUnit lu;
	ProductDetect pd;
	String url = "https://www.saucedemo.com";
  @BeforeMethod
  public void launchbrowser() {
	  	driver = Utilities.launch_browser("chrome", url);
		lu = new LoginUnit(driver);
		pd = new ProductDetect(driver);
  } 
 	@BeforeClass
 	public void get_data() 
 	{
 		get_test_data();
 	}
 	
 	 @DataProvider(name="login_data")
 	  public String[][] provide_data()
 	  {
 	 	 return testdata;
 	  }
  @Test(dataProvider = "login_data")
  public void logintest(String eid, String pwd, String exp_eid) 
  {
 	 String act_pro;
 	 pd.verify_title();
 	 lu.do_loginunit(eid, pwd);
 	 act_pro = pd.get_text();
 	 System.out.println(act_pro);
 	Assert.assertEquals(act_pro, exp_eid);
 	System.out.println("login successful");
  }
  @AfterMethod
   public void afterMethod() {
	  driver.quit();
  }

}

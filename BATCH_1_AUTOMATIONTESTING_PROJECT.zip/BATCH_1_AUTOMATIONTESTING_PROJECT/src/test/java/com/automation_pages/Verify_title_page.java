package com.automation_pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Verify_title_page {
	Logger LOG = Logger.getLogger( Verify_title_page.class.getName());
	 WebDriver driver;
	String act_title;


	

	
	public Verify_title_page(WebDriver driver) 
	{
		this.driver =driver;
	}

	// Get the actual title
	public void automation_getacttitle() {
		

		 act_title = driver.getTitle();
		LOG.info("actual title is taken from the application ");
	}
	
	//compare the actual and expected title
	public void automation_verifytitle() {
		//String exp_title ="Automation Practice Site";
		 act_title = driver.getTitle();
		System.out.println(act_title);
		if(act_title.equals("Automation Practice Site"))
		{
			System.out.println("TITLE MATCHED");
		}
		else
		{
			System.out.println("not matched");
		}
		/*if(act_title.equalsIgnoreCase(exp_title))
			System.out.println("Title Matched");
		
		else
			System.out.println("Title didn't match");*/
		LOG.info(" Title verified");
		
		
	
	
	}

}

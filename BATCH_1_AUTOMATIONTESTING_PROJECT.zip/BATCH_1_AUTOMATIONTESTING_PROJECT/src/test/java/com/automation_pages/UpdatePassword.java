package com.automation_pages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class UpdatePassword {
	WebDriver driver;
	By Myaccount=By.linkText("My Account");
	By Username=By.id("username");
	By Password=By.id("password");
	By login=By.xpath("//input[@name='login']");
	By accountfirstname=By.id("account_first_name");
	By accountlastname=By.id("account_last_name");
	By passwordcurrent=By.id("password_current");
	By password1=By.id("password_1");
	By password2=By.id("password_2");
	By accountdetails=By.linkText("Account Details");
	By saveaccountdetails=By.name("save_account_details");

	public UpdatePassword(WebDriver driver) 
	{
		this.driver=driver;
	}
	//To check account details
	public void clickAccountDetails() {
		driver.findElement(accountdetails).click();
	}
	//To fill change password
	public void fillChangePassword() {
		driver.findElement(accountfirstname).clear();
		driver.findElement(accountfirstname).sendKeys("Bhargavi");
		driver.findElement(accountlastname).clear();
		driver.findElement(accountlastname).sendKeys("Nagalla");
		driver.findElement(passwordcurrent).sendKeys("Bhargavinagalla");
		driver.findElement(password1).sendKeys("Bhargavinagalla");
		driver.findElement(password1).click();
		driver.findElement(password2).sendKeys("Bhargavinagalla");
		
	}
	//To save changes
	public void clickSaveChanges() {
		driver.findElement(saveaccountdetails).click();
	}
	
	//To take screenshot
	public void Screenshot() throws Exception {
		TakesScreenshot ts= (TakesScreenshot)driver;
		File source=ts.getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(source,new File("\\Screenshots\\PasswordUpdated.png"));
	}
	//To close the browser window
		public void quit() {
			driver.close();
		}
}

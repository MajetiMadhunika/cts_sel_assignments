package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 {
	WebDriver driver;
	@Given("^Login page is displayed$")
	public void login_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println("Login page is displayed");
	    System.setProperty("webdriver.chrome.driver", "D:/my office/chromedriver_win32/chromedriver.exe");
	    driver = new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com/login");
	}

	@When("^User enters login data and clicks ok button$")
	public void user_enters_login_data_and_clicks_ok_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("majetimadhunika@gmail.com");
		driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("manny12397");
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	}
	@Then("^Home page is displayed$")
	public void home_page_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   String a_email=driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	   SoftAssert sa = new SoftAssert();
	   sa.assertEquals(a_email, "majetimadhunika@gmail.com");
	   sa.assertAll();
	   driver.quit();
	}
	
	 @When("^User enters INVALID email id, valid pwd and clicks ok button$")
	   public void user_enters_INVALID_email_id_valid_pwd_and_clicks_ok_button() throws Throwable {
	       // Write code here that turns the phrase above into concrete actions
		 driver.findElement(By.xpath("//*[@id=\"Email\"]")).sendKeys("majetimadhurima@gmail.com");
		 driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("manny12397");
		 driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		}

	   @Then("^Login page is displayed with err msg - No customer found account found$")
	   public void login_page_is_displayed_with_err_msg_No_customer_found_account_found() throws Throwable {
	       // Write code here that turns the phrase above into concrete actions
	 	  driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[1]/div/span")).getText();
		  System.out.println("Login is unsuccessful");
	 	  driver.quit();
	   }
	}


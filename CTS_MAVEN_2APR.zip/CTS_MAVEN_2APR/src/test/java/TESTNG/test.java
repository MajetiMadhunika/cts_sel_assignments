package TESTNG;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test {
  @Test
  public void f() {
	  System.out.println("in testng");
	  System.setProperty("webdriver.chrome.driver", "D:/my office/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
  }
}

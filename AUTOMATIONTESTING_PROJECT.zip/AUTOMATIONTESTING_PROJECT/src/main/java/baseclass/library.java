package baseclass;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class library 
{
	protected WebDriver driver;
	public static Properties prop;
	private static Logger LOG=(Logger) LogManager.getLogger(library.class);
	//To launch
	public WebDriver launchApp() throws IOException 
	{
		FileInputStream fis =new FileInputStream("C:\\Users\\majeti\\eclipse-workspace\\AUTOMATIONTESTING_PROJECT\\src\\test\\resources\\config.property\\config.properties");
		prop =new Properties();
		prop.load(fis);
		String browser = prop.getProperty("browser");

	//launch Chrome Browser
	if(browser.equalsIgnoreCase("chrome")) 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\majeti\\eclipse-workspace\\AUTOMATIONTESTING_PROJECT\\src\\test\\resources\\drivers\\chromedriver.exe");
		driver = new ChromeDriver();
		LOG.info("Chrome is Launched");
	}
	
	//Launch Firefox Broswer
	else if (browser.equalsIgnoreCase("firefox")) 
	{
		System.setProperty("webdriver.gecko.driver", "C:\\Users\\majeti\\eclipse-workspace\\AUTOMATIONTESTING_PROJECT\\src\\test\\resources\\drivers\\geckodriver.exe");
		driver = new FirefoxDriver();
		LOG.info("FireFox is Launched");
	}
	driver.manage().window().maximize();
	LOG.info("Window is Maximized");
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.get(prop.getProperty("url"));
	LOG.info("URL is entered");
	return driver;
	}
	 //To close the application
	 public void quit() 
	 {
	 driver.close();
	  }
	}


package SWAGLABSPAGEASS2;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;

@Test
public class LoginTest {
	WebDriver driver;
	LoginUnit lu;
	ProductDetect pd;
  
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver", "D:/my office/chromedriver_win32/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.saucedemo.com/");
		lu = new LoginUnit(driver);
		pd = new ProductDetect(driver);
}
  
  public void LoginUnit() {
	  String Title_str = pd.verify_title();
	  String exp_str = "Swag Labs";
	  Assert.assertEquals(Title_str, exp_str);
	  lu.do_loginunit("standard_user", "secret_sauce");
	  lu.successful_login();
	  String st1 = lu.verify_text(driver);
	  System.out.println(st1);
  }
  
  @AfterMethod
   public void afterMethod() {
	  driver.quit();
  }

}

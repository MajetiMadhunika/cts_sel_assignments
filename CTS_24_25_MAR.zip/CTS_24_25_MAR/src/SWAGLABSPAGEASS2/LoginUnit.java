package SWAGLABSPAGEASS2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginUnit 
{
	WebDriver driver1;
	By UserName = By.id("user-name");
	By Pwd = By.id("password");
	By prd = By.className("inventory_item_name");
	By login_btn = By.className("btn_action");
	
	public LoginUnit(WebDriver driver)
	{
		this.driver1=driver;
	}
	
	public void enter_UserName_id(String UserNameid)
	{
		driver1.findElement(UserName).sendKeys(UserNameid);
	}
	   
	public void enter_password_id(String password)
	{
		driver1.findElement(Pwd).sendKeys(password);
	}
	
	public void click_login_btn()
	{
		driver1.findElement(login_btn).click();
	}
	
	public void do_loginunit(String UserNameid,String password)
	{
		this.enter_UserName_id(UserNameid);
		this.enter_password_id(password);
		this.click_login_btn();
	}

	public void successful_login() {
		System.out.println("Login Successful");
	}

	public String verify_text(WebDriver driver) {
		this.driver1=driver;
		String st1 = driver1.findElement(prd).getText();
		return st1;
	}
}

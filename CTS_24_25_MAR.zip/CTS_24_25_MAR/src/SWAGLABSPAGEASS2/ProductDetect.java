package SWAGLABSPAGEASS2;

import org.openqa.selenium.WebDriver;

public class ProductDetect {
	WebDriver driver2;
	public ProductDetect(WebDriver driver)
	{
		this.driver2=driver;
	}
	public String verify_title()
	{
		String str = driver2.getTitle();
		return str;
	}
}

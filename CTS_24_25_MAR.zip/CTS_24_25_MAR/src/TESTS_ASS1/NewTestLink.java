package TESTS_ASS1;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import PAGES_ASS1.HOME_PAGE;
import PAGES_ASS1.LOGIN_PAGE;
import PAGES_ASS1.PROFILE_PAGE;
public class NewTestLink 
{	
	WebDriver driver;
	HOME_PAGE hp;
	LOGIN_PAGE lp;
	PROFILE_PAGE pp;
	
	@BeforeMethod
	public void launchbrowser()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\my office\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com/");
		hp = new HOME_PAGE(driver);
		lp = new LOGIN_PAGE(driver);
		pp = new PROFILE_PAGE(driver);
	}
	
  @Test
  public void logintest() 
  {
	  String exp_pn = "majetimadhunika@gmail.com", act_pn;
	  
	  hp.click_login_link();
	  lp.do_login("majetimadhunika@gmail.com", "manny12397");
	  act_pn = pp.get_profilename();
	  
	  Assert.assertEquals(act_pn,exp_pn);
  }
  
  @AfterMethod
	public void afterMethod()
	{
		driver.quit();
	}
}

package com.cts.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DemoWebShop1 
{
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "D:/my office/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demowebshop.tricentis.com");
		driver.findElement(By.className("ico-login")).click();
		driver.findElement(By.id("Email")).sendKeys("majetimadhunika@gmail.com");
		driver.findElement(By.id("Password")).sendKeys("manny12397");
		//driver.findElement(By.id("RememberMe")).click();
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS); 
		driver.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		driver.findElement(By.className("ico-logout")).click();

	}
}

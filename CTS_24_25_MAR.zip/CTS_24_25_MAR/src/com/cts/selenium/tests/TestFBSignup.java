package com.cts.selenium.tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class TestFBSignup 
{
	public static void main(String[] args) 
	{
		System.setProperty("webdriver.chrome.driver", "D:/my office/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://facebook.com");
		
		driver.findElement(By.name("firstname")).sendKeys("Madhu");
		driver.findElement(By.name("lastname")).sendKeys("Majeti");
		driver.findElement(By.name("reg_email__")).sendKeys("9502730597");
		driver.findElement(By.name("reg_passwd__")).sendKeys("madhu1565");
		
	    Select day = new Select(driver.findElement(By.id("day")));
	    day.selectByVisibleText("3");
	    
	    Select month = new Select(driver.findElement(By.id("month")));
	    month.selectByIndex(5);
	    
	    Select year = new Select(driver.findElement(By.id("year")));
	    year.selectByValue("1997");
	    
	    WebElement gender = driver.findElement(By.id("u_0_6"));
	    gender.click();
	    
	    driver.findElement(By.id("u_0_13")).click();
	    
	}
}

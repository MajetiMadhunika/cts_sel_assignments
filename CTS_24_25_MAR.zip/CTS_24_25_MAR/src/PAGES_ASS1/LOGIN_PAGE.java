package PAGES_ASS1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class LOGIN_PAGE 
{
	WebDriver driver2;
	By eid = By.id("Email");
	By pwd = By.id("Password");
	By login_btn = By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input");
	
	public LOGIN_PAGE(WebDriver driver)
	{
		this.driver2=driver;
	}
	
	public void enter_email_id(String emailid)
	{
		driver2.findElement(eid).sendKeys(emailid);
	}
	
	public void enter_password_id(String password)
	{
		driver2.findElement(pwd).sendKeys(password);
	}
	
	public void click_login_btn()
	{
		driver2.findElement(login_btn).click();
	}
	
	public void do_login(String emailid,String password)
	{
		this.enter_email_id(emailid);
		this.enter_password_id(password);
		this.click_login_btn();
	}
}

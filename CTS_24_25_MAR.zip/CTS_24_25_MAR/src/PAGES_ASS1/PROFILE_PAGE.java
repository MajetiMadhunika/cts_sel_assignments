package PAGES_ASS1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PROFILE_PAGE {
	By xp_profilename = By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a");
	WebDriver driver3;
	
	public PROFILE_PAGE(WebDriver driver)
	{
		driver3=driver;
	}
	
	public String get_profilename()
	{
		String pname = driver3.findElement(xp_profilename).getText();
		return pname;	
	}
}

package PAGES_ASS1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class HOME_PAGE 
{
	WebDriver driver1;
	By login_link = By.linkText("Log in");
	By register_link = By.linkText("Register");

	public HOME_PAGE(WebDriver driver)
	{
		this.driver1=driver;
	}
	
	public void click_register_link()
	{
		driver1.findElement(register_link).click();
	}
	
	public void click_login_link()
	{
		driver1.findElement(login_link).click();
	}
}

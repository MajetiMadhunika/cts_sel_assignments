package KWDFW;

public class test {

	public static void main(String[] args) {
		excel_operations excel = new excel_operations();
		String data = excel.read_excel(0,0);
		System.out.println("Data : "+ data);
		excel.write_excel1(0, 0, "Selenium");
		excel.write_excel2(1, 1, "Switch");
		excel.write_excel3(2, 0, "excel");
	}

}

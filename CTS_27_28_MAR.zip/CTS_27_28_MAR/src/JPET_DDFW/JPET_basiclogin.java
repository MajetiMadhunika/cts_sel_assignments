package JPET_DDFW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JPET_basiclogin {

	public static String login(String uid, String pwd)
	{
		String a_result;
		System.setProperty("Webdriver.chrome.driver", "D:/my office/chromedriver_win32/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://jpetstore.cfapps.io/login");
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys(uid);
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys(pwd);
		driver.findElement(By.xpath("//input[@value='Login']")).click();
		String a_eid = driver.findElement(By.xpath("//*[@id=\"WelcomeContent\"]/div/span")).getText();
		driver.close();
		return a_eid;
	}

}

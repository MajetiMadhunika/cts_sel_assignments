package DDFW;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class dataprovider_login {
	basic_login test;
  @Test(dataProvider="login_data")
  public void logintest(String eid, String pwd, String exp_eid) {
	  test = new basic_login();
	  String a_eid = test.login(eid, pwd);
	  SoftAssert sa = new SoftAssert();
	  sa.assertEquals(a_eid, exp_eid);
	  sa.assertAll();
  }
  
  @DataProvider(name="login_data")
  public String[][] provide_data()
  {
	  String[][] data = { 
			  {"majetimadhunika@gmail.com", "manny12397", "majetimadhunika@gmail.com"},
			  {"majetimadhunika@gmail.com", "manny12397", "majetimadhurima@gmail.com"}
	  };
	return data;
	  
  }
}

package READ_WRITE_EXCEL;

public class test_write {

	public static void main(String[] args) {
		excel_operations1 excel = new excel_operations1();
		excel.write_excel(1, 1, "TestNG");
		String Data = excel.read_excel(1,1);
		System.out.println("Data : "+Data);
	}
}
